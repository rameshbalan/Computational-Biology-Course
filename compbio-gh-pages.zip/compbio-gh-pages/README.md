# Introduction to Computational Biology

* Instructor: [Michael Love](http://mikelove.github.io)
* [Course website](http://biodatascience.github.io/compbio)
* [Source Rmarkdown files](http://github.com/biodatascience/compbio_src)
